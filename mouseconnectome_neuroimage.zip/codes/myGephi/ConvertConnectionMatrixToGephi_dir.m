%cojoc(at)hotmail.com
%2011-5-30
%will convert connectoin matrix to the .gexf format readable to gephi
%the matrix is directional: Mat(i,j) is the connection weight from i to j
%http://gephi.org/
%Mat: n*n, weighted connection matrix
%fname_output: output file name, don't need appendex
%label: n*1 cell, the name of each point (optional)
%T_max: maximum threshold of weight, if weight > T_max, weight = T_max (optional)
%color: n*3, r/g/b color of each nodes (optional)
%coord: n*3, x/y/z coordinate of each nodes (optional)
function [] = ConvertConnectionMatrixToGephi_dir(Mat, fname_output, label, T_max, color, Coord)
    edge_T=0.01;
    fw=fopen([fname_output '.gexf'],'w');
    %file header
    fprintf(fw,'<?xml version="1.0" encoding="UTF-8"?>\n');
    fprintf(fw,'<gexf xmlns="http://www.gephi.org/gexf" xmlns:viz="http://www.gephi.org/gexf/viz">\n');
    fprintf(fw,'<graph type="static">\n');
    fprintf(fw,'<attributes class="node" type="static">\n');
    fprintf(fw,'<attribute id="label" title="label" type="string"/>\n');
    fprintf(fw,'</attributes>\n');
    %output nodes descripter
    fprintf(fw,'<nodes>\n');
    
    for i=1:size(Mat,1)
        if nargin>3
            fprintf(fw,'<node id="%03d" label="%s">\n',i-1,label{i});
        else
            fprintf(fw,'<node id="%03d" label="%d">\n',i-1,i-1);
        end
        if nargin>5
            fprintf(fw,'<viz:position x="%.4f" y="%.4f" z="%.4f"/>\n',Coord(i,1)*10,Coord(i,2)*10,Coord(i,3))*10;
        end
        if nargin>4
            fprintf(fw,'<viz:color b="%d" g="%d" r="%d"/>\n',color(i,3),color(i,2),color(i,1));
        end
        fprintf(fw,'</node>\n');
    end
    fprintf(fw,'</nodes>\n');
    %output edge descripter
    edge_idx=0;
    fprintf(fw,'<edges>\n');
    for i=1:size(Mat,1)
        for j=1:size(Mat,2)
            if i==j
                continue;
            end
            if Mat(i,j)>edge_T
                if Mat(i,j)>T_max
                    weight = T_max;
                else
                    weight = Mat(i,j);
                end
                fprintf(fw,'<edge id="%d" source="%03d" target="%03d" weight="%.2f"/>\n',edge_idx,i-1,j-1,abs(weight));
                edge_idx = edge_idx + 1;
            end
        end
    end
    fprintf(fw,'</edges>\n');
    %file footer
    fprintf(fw,'</graph>\n');
    fprintf(fw,'</gexf>\n');
    
    fclose(fw);
end