%cojoc(at)hotmail.com
%2011-5-30
%will convert connectoin matrix to the .gexf format readable to gephi
%http://gephi.org/
%Mat: n*n, weighted connection matrix
%Coord: n*3, x/y/z coordinate of each nodes
%T_max: maximum threshold of weight, if weight > T_max, weight = T_max
%fname_output: output file name, don't need appendex
function [] = ConvertConnectionMatrixToGephi(Mat, Coord, T_max, fname_output)
    edge_T=0.1;
    fw=fopen([fname_output '.gexf'],'w');
    %file header
    fprintf(fw,'<?xml version="1.0" encoding="UTF-8"?>\n');
    fprintf(fw,'<gexf xmlns="http://www.gephi.org/gexf" xmlns:viz="http://www.gephi.org/gexf/viz">\n');
    fprintf(fw,'<graph type="static">\n');
    fprintf(fw,'<attributes class="node" type="static">\n');
    fprintf(fw,'<attribute id="label" title="label" type="string"/>\n');
    fprintf(fw,'</attributes>\n');
    %output nodes descripter
    fprintf(fw,'<nodes>\n');
    for i=1:size(Mat,1)
        fprintf(fw,'<node id="%d" label="%d">\n',i-1,i-1);
        fprintf(fw,'<viz:position x="%.4f" y="%.4f" z="%.4f"/>\n',Coord(i,1)*10,Coord(i,2)*10,Coord(i,3));
        fprintf(fw,'<viz:color b="0" g="204" r="0"/>\n');
        fprintf(fw,'</node>\n');
    end
    fprintf(fw,'</nodes>\n');
    %output edge descripter
    edge_idx=0;
    fprintf(fw,'<edges>\n');
    for i=1:size(Mat,1)-1
        for j=i+1:size(Mat,2)
            if Mat(i,j)>edge_T
                if Mat(i,j)>T_max
                    weight = T_max;
                else
                    weight = Mat(i,j);
                end
                fprintf(fw,'<edge id="%d" source="%d" target="%d" weight="%.2f"/>\n',edge_idx,i-1,j-1,abs(weight));
                edge_idx = edge_idx + 1;
            end
        end
    end
    fprintf(fw,'</edges>\n');
    %file footer
    fprintf(fw,'</graph>\n');
    fprintf(fw,'</gexf>\n');
    
    fclose(fw);
end