%cojoc(at)hotmail.com
%2014.2.26

%visualize cluster
%S: similarity matrix
%C: cluster label
function visualizeCluster(S, C)
[ignore P]=sort(C);
list=unique(C);
rect=[];
x=0.5;y=0.5;
for j=1:length(list)
    w=sum(C==list(j));
    rect=[rect; x, y, w, w];
    x=x+w;
    y=y+w;
end    

fig=figure;
imagesc(S(P,P)); colormap hot; axis equal; axis off; hold on;
set(gcf, 'PaperSize', [4 4]);
set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperPosition', [0 0 4 4]);
for k=1:size(rect,1)
    rectangle('Position',rect(k,:),'EdgeColor','green');
end
end