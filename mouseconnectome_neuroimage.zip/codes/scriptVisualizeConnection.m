%cojoc(at)hotmail.com

addpath D:\bio\codes\matlab\gephi\
nodeNum=268;

%visualize using gephi
%generate color file
color=zeros(nodeNum,3);
% color(C==1,1)=255;
% color(C==2,1)=255;
% color(C==3,3)=255;
% color(C==4,:)=128;
for i=1:nodeNum
    id=find(idTable==list(i));
    color(i,1)=floor(hex2dec(allList{id}.color)/(256*256));
    color(i,2)=floor(mod(hex2dec(allList{id}.color),256*256)/256);
    color(i,3)=mod(hex2dec(allList{id}.color),256);
end

%generate label
label=cell(nodeNum,1);
for i=1:nodeNum
    id=find(idTable==list(i));
    label{i}=allList{id}.acronym;
end

%get coordinate
coord=load('coord_268.txt');

coord(:,1)=coord(:,1)*-1;
coord(:,2)=coord(:,2)*-1;
coord(:,3)=0;

%generate gephi files
ConvertConnectionMatrixToGephi_dir(fiberConn,'fiber_all',label,1000,color,coord);
ConvertConnectionMatrixToGephi_dir(traceConn,'trace_all',label,0.1,color,coord);
ConvertConnectionMatrixToGephi_dir(traceConn_max,'traceMax_all',label,1,color,coord);
% 
% ConvertConnectionMatrixToGephi_dir(traceConn(C<4,C<4),'trace_fear',label(C<4),1000,color(C<4,:));