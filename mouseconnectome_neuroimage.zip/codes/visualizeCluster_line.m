%cojoc(at)hotmail.com
%2014.2.26

%visualize cluster
%S: similarity matrix
%C: cluster label
function visualizeCluster_line(S, C)
[ignore P]=sort(C);
list=unique(C);
rect=[];
x=0.5; y=length(P);
for j=1:length(list)
    w=sum(C==list(j));
    rect=[rect, x];
    x=x+w;
end  

fig=figure;
imagesc(S(P,P)); colormap hot; axis equal; axis off; hold on;
set(gcf, 'PaperSize', [4 4]);
set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperPosition', [0 0 4 4]);
for k=1:length(rect)
    line([rect(k) rect(k)],[0 y],'Color',[0 1 0]);
    line([0 y], [rect(k) rect(k)],'Color',[0 1 0]);
end
end