function [degree,coverage,hinge,jointsGraph]=coAnalysisGyriNetwork(G, surf, vtx1)
%cojoc(at)hotmail.com
%2016/1/7
%[degree,hinge,graph]=coAnalysisGyriNetwork(G, vtx)
%Input:
%   G: n*n matrix of the connectivity between n vertices
%   surf.Vtx: 3*n matrix of cooridnate of n vertices
%   surf.Face:
%Output:
%   degree
%       degree.stat: [1/2/3/4], number of vertices with degree==1/==2/==3/>3
%       degree.all: the degree of all vertices
%   coverage: coverage rate of gyral crest between geodesic/euclidean dis.
%       coverage.rate: # of vertex covered in radius by gdist over edist
%       coverage.gdist: geodesic distance between node on gyral network 
%       coverage.edist: Euclidean distance between node on gyral network
%       coverage.vtxList: list of gyral network vertices index
%   hinge: m crest hinges between vertices with degree =1 or >=3
%       hinge.info(:,[1,2]): vertex id of the hinge end
%       hinge.info(:,[3,4]): geodesic/euclidean distance between hinge ends
%       hinge.path{i}: list of vertices along the hinge
%   graph: connectivity between joint points
%       graph.mat: k * k connectivity matrix
%       graph.emat: k * k connectivity matrix, Euclidean distance
%       graph.gmat: k * k connectivity matrix, geodesic distance
%       graph.nodeList: vertex id of k joint points
%       graph.edge: edge informations
%       graph.edge(:,[1,2]): node id from 1 to k
%       graph.edge(:,[3,4]): geodesic/euclidean distance between nodes
%load test.mat
%G=gyriNetwork;
vtx=surf.Vtx;

degreeHist=zeros(4,1); %[1/2/3/4]:degree==1/==2/==3/>3, 
degreeHist(1)=full(sum(sum(G)==1));
degreeHist(2)=full(sum(sum(G)==2));
degreeHist(3)=full(sum(sum(G)==3));
degreeHist(4)=full(sum(sum(G)>3));
degree.stat=degreeHist;
degree.all=full(sum(G));

%%
%%coverage
%distance matrix
vtxList=find(full(sum(G)>0));
coordList=vtx(:,vtxList);
%geodesic distance alone the GCN
[x,y]=find(triu(G)>0);
s=zeros(1,length(x));
t=zeros(1,length(x));
weight=zeros(1,length(x));
G_edge=zeros(length(vtxList));
for i=1:length(x)
    a=find(vtxList==x(i));
    b=find(vtxList==y(i));
    s(i)=a;
    t(i)=b;
    weight(i)=norm(coordList(:,a)-coordList(:,b));
    G_edge(a,b)=weight(i);
    G_edge(b,a)=weight(i);
end
totalLen=sum(weight);
G_graph=graph(s,t,weight);
gdall=distances(G_graph); 
%euclidean distance between the GCN
edall=dist(coordList);
rlist=[5 10 15];
coverageRate=zeros(length(rlist),length(vtxList));
for i=1:length(rlist)
    coverageRate(i,:)=sum(gdall<rlist(i))./sum(edall<rlist(i));
end
%geodesic distance on the surface
surf_G=sparse([surf.Face(1,:),surf.Face(1,:),surf.Face(2,:),surf.Face(2,:),surf.Face(3,:),surf.Face(3,:)],...
    [surf.Face(2,:),surf.Face(3,:),surf.Face(3,:),surf.Face(1,:),surf.Face(1,:),surf.Face(2,:)],...
    ones(1,2*length([surf.Face(2,:),surf.Face(3,:),surf.Face(3,:)])));
[x,y]=find(triu(surf_G)>0);
weight=zeros(1,length(x));
for i=1:length(x)
    weight(i)=norm(vtx(:,x(i))-vtx(:,y(i)));
end
G_graph=graph(x,y,weight);
sgdall=distances(G_graph,vtxList,vtxList);

coverage.gdist=gdall;
coverage.edist=edall;
coverage.sdist=sgdall;
coverage.rate=coverageRate;
coverage.vtxList=vtxList;
coverage.gdist_sum=totalLen;
coverage.edges=G_edge;

%%
%%coverage on another surface
if(nargin>2)
    if(size(vtx,2)~=size(vtx1,2))
        error('number of input vertices does not agree');
    end
    coordList=vtx1(:,vtxList);
    [x,y]=find(triu(G)>0);
    s=zeros(1,length(x));
    t=zeros(1,length(x));
    weight=zeros(1,length(x));
    G_edge=zeros(length(vtxList));
    for i=1:length(x)
        a=find(vtxList==x(i));
        b=find(vtxList==y(i));
        s(i)=a;
        t(i)=b;
        weight(i)=norm(coordList(:,a)-coordList(:,b));
        G_edge(a,b)=weight(i);
        G_edge(b,a)=weight(i);
    end
    totalLen=sum(weight);
    G_graph=graph(s,t,weight);
    gdall=distances(G_graph); %geodesic distance alone the GCN
    edall=dist(coordList);
    rlist=[10 20 30];
    coverageRate=zeros(length(rlist),length(vtxList));
    for i=1:length(rlist)
        coverageRate(i,:)=sum(gdall<rlist(i))./sum(edall<rlist(i));
    end
    [x,y]=find(triu(surf_G)>0);
    weight=zeros(1,length(x));
    for i=1:length(x)
        weight(i)=norm(vtx(:,x(i))-vtx(:,y(i)));
    end
    G_graph=graph(x,y,weight);
    sgdall=distances(G_graph,vtxList,vtxList);

    coverage.gdist1=gdall;
    coverage.edist1=edall;
    coverage.sdist1=sgdall;
    coverage.rate1=coverageRate;
    coverage.gdist_sum1=totalLen;
    coverage.edges1=G_edge;
end
%%
%%distance between nodes
if nargout>3
    nodeList=find(full(sum(G)>0 & sum(G)~=2));
    mask=zeros(size(G,1),1);
    edgeList=[]; %source idx, target idx, source vtx, target vtx, geo Distance, eu distance 
    edgePath=[];

    for i=1:length(nodeList)
    %     fprintf('\r%d/%d',i,length(nodeList));
        node=nodeList(i);
        mask(node)=node;
        neighborList=find(full(G(node,:)>0));
        for j=1:length(neighborList)
            if(mask(neighborList(j))>0)
                continue;
            end
            pid=node;
            nid=neighborList(j);
            path=[pid,nid];
            mask(nid)=node;
            gdis=norm(vtx(:,pid)-vtx(:,nid));
            while full(sum(G(nid,:)))==2
                pid=nid;
                tmp=find(full(G(nid,:)>0));
                if(mask(tmp(1)) ~= node)
                    nid=tmp(1);
                elseif(mask(tmp(2)) ~= node)
                    nid=tmp(2);
                elseif full(sum(G(tmp(1),:)))~=2
                    nid=tmp(1);
                elseif full(sum(G(tmp(2),:)))~=2
                    nid=tmp(2);
                else
                    disp([i j node nid tmp(1) tmp(2) mask(tmp(1)) mask(tmp(2))]);
                end
                gdis=gdis+norm(vtx(:,pid)-vtx(:,nid));
                mask(nid)=node;
                path=[path,nid];
            end
            edgeList=[edgeList;i,find(nodeList==nid),node,nid,gdis,norm(vtx(:,nid)-vtx(:,node))];
            edgePath{size(edgeList,1)}=path;
        end
    end

    mat=zeros(length(nodeList));
    emat=zeros(length(nodeList));
    gmat=zeros(length(nodeList));
    for i=1:size(edgeList,1)
        mat(edgeList(i,2),edgeList(i,1))=mat(edgeList(i,2),edgeList(i,1))+1;
        mat(edgeList(i,1),edgeList(i,2))=mat(edgeList(i,1),edgeList(i,2))+1;
        emat(edgeList(i,2),edgeList(i,1))=emat(edgeList(i,2),edgeList(i,1))+edgeList(i,6);
        emat(edgeList(i,1),edgeList(i,2))=emat(edgeList(i,1),edgeList(i,2))+edgeList(i,6);
        gmat(edgeList(i,2),edgeList(i,1))=gmat(edgeList(i,2),edgeList(i,1))+edgeList(i,5);
        gmat(edgeList(i,1),edgeList(i,2))=gmat(edgeList(i,1),edgeList(i,2))+edgeList(i,5);
    end
    emat=emat./mat;
    gmat=gmat./mat;

    hinge.info=edgeList(:,3:end);
    hinge.path=edgePath;
    jointsGraph.node=nodeList;
    jointsGraph.edge=edgeList(:,[1,2,5:end]);
    jointsGraph.mat=mat;
    jointsGraph.emat=emat;
    jointsGraph.gmat=gmat;
end

end