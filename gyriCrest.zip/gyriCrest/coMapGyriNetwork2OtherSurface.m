function [gyriNetwork,surf]=coMapGyriNetwork2OtherSurface(fname_GN_mat, fname_surf, fname_out)
addpath /home/caidGroup/Researcher/uga_hanbo/matlab/myVtk %vtkI/O
addpath /home/exe/freesurfer/matlab %freesurfer I/O    
load(fname_GN_mat);
[vtx,face]=read_surf(fname_surf);
face=face'+1;
vtx=vtx';
if(size(vtx,2)~=size(surf.Vtx))
    error('the number of surface vertex number does not match!');
end
surf.Vtx=vtx;
surf.Face=face;
if nargin>2
    if(strcmp([fname_out '.mat'],fname_GN_mat))
        error('the source network file and assigned output has the same name.');
    end
    Gout=gyriNetwork; %G;
    tmp=find(triu(Gout)>0);
    [S,T]=ind2sub([size(vtx,2),size(vtx,2)],tmp);
    fp=fopen([fname_out '_tree_skel.vtk'],'w');
    fprintf(fp,'# vtk DataFile Version 3.0\nROI Point\nASCII\nDATASET POLYDATA\n');
    fprintf(fp,'POINTS %d float\n',size(vtx,2));
    fprintf(fp,'%f %f %f\n',vtx);
    fprintf(fp,'LINES %d %d\n',length(S),length(S)*3);
    for i=1:length(S)
        fprintf(fp,'2 %d %d\n',S(i)-1,T(i)-1);
    end
    fclose(fp);
    
    save([fname_out '.mat'],'gyriNetwork','surf');
end
end