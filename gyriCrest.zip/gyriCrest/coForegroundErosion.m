%cojoc(at)hotmail.com
%erosion
%region: 1 foreground, 0 background
%neighbor{i}: the neighbors of vtx i
function [after]=coForegroundErosion(neighbor, region)
    after=region;
    for idx=find(region>0)'
        if(sum(region(neighbor{idx})<=0)>0)
            after(idx)=0;
        end
    end
end