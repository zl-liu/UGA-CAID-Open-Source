%cojoc(at)hotmail.com
%2/15/2016

function coSaveNetwork_vtk(fname_output,gyriNetwork,vtx,label)
%coSaveNetwork_vtk(gyriNetwork,vtx,label)
%   fname_output: filename
%   gyriNetwork: n*n matrix
%   vtx: 3*n matrix of x,y,z coordinate
%   label: i*n matrix of labels
    fp=fopen(fname_output,'w');
    if fp<=0
        error(['cannot open file ' fname_output 'for read']);
    end

    Gout=gyriNetwork;
    tmp=find(triu(Gout)>0);
    [S,T]=ind2sub(size(Gout),tmp);
    fprintf(fp,'# vtk DataFile Version 3.0\nROI Point\nASCII\nDATASET POLYDATA\n');
    fprintf(fp,'POINTS %d float\n',size(Gout,1));
    fprintf(fp,'%f %f %f\n',vtx);
    fprintf(fp,'LINES %d %d\n',length(S),length(S)*3);
    for i=1:length(S)
        fprintf(fp,'2 %d %d\n',S(i)-1,T(i)-1);
    end
    if(nargin>3)
        fprintf(fp,'POINT_DATA %d\n',size(Gout,1));
        for i=1:size(label,1)
            fprintf(fp,'SCALARS label_%d float\n',i);
            fprintf(fp,'LOOKUP_TABLE Label_%d\n',i);
            fprintf(fp,'%f\n',label(i,:));
        end
    end
    fclose(fp);
    