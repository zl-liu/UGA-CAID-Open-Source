%cojoc(at)hotmail.com
%erosion
%region: 1 foreground, 0 background
%neighbor{i}: the neighbors of vtx i
function [after]=coForegroundDialation(neighbor, region)
    after=region;
    for idx=find(region>0)'
        after(neighbor{idx})=1;
    end
end