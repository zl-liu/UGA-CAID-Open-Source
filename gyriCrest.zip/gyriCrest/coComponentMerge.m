%cojoc(at)hotmail.com
%connected region
%region: 1 foreground, 0 background
%neighbor{i}: the neighbors of vtx i
function [label]=coComponentMerge(neighbor, label, level, thr)
    components=unique(label);
    components=components(components>0);
    border=cell(max(components));
    newlabel=1:max(components);
    for cid=components'
        regions=[];
        for vid=find(label==cid)'
            regions=[regions; neighbor{vid}];
        end
        regions=unique(regions);
        tmp=unique(label(regions));
        tmp(tmp<=0)=[];
        tmp(tmp==cid)=[];
        for i=1:length(tmp)
            crid=tmp(i);
            border{cid,crid}=intersect(find(label==crid),regions);
        end
    end
    for i=1:length(components)
        for j=i+1:length(components)
            cidi=components(i);
            cidj=components(j);
            tmp=[border{cidi,cidj};border{cidj,cidi}];
            if ~isempty(tmp) %check to see if need to merge when they have border
                l_border=max(level(tmp));
                l_i=1e10; %min(level(label==cidi));
                for ni=find(newlabel==newlabel(cidi))
                    l_itmp=min(level(label==ni));
                    l_i=min(l_i,l_itmp);
                end
                l_j=1e10; %min(level(label==cidj));
                for nj=find(newlabel==newlabel(cidj))
                    l_jtmp=min(level(label==nj));
                    l_j=min(l_j,l_jtmp);
                end
                if (l_border-l_i<thr) || (l_border-l_j<thr)
%                     disp([l_border-l_i l_border-l_j thr cidi cidj]);
                    newlabel(newlabel==newlabel(cidj))=newlabel(cidi);
                end
            end
        end
    end
    tmp=unique(newlabel);
    for i=1:length(tmp)
        newlabel(newlabel==tmp(i))=i;
    end
    tmplabel=label;
    for i=1:length(newlabel);
        label(tmplabel==i)=newlabel(i);
    end
end