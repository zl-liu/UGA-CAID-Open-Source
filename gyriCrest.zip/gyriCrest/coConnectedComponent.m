%cojoc(at)hotmail.com
%connected region
%neighbor{i}: the neighbors of vtx i
%region: 1 foreground, 0 background
function [label]=coConnectedComponent(neighbor, region)
    label=zeros(length(neighbor),1);
    label(:)=0;
    lid=1;
    while sum(region>0)>0
        seed=find(region>0,1);
        label(seed)=lid;
        region(seed)=0;
        idx=1;
        while idx<=length(seed)
            tmp=seed(idx);
            for nid=neighbor{tmp}'
                if region(nid)>0
                    seed=[seed nid];
                    label(nid)=lid;
                    region(nid)=0;
                end
            end
            idx=idx+1;
        end
        lid=lid+1;
    end
end