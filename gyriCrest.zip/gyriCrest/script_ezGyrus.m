%cojoc(at)hotmail.com
%2015/1/25
% 
% addpath D:\bio\codes\matlab\myVtk
% 
% %load data
% surf=vtkSurfRead('1.L.white_matter_surface.vtk');
% face=surf.Face;
% mask=surf.Pdata{5}.val>0;
% level=surf.Pdata{1}.val;
% 
% %
% %1st. construct neighborhood
% neighbor=cell(size(surf.Vtx,2),1);
% for i=1:size(face,2)
%     neighbor{face(1,i)}=[neighbor{face(1,i)};face(2:3,i)];
%     neighbor{face(2,i)}=[neighbor{face(2,i)};face([1 3],i)];
%     neighbor{face(3,i)}=[neighbor{face(3,i)};face(1:2,i)];
% end
% for i=1:length(neighbor)
%     neighbor{i}=unique(neighbor{i});
% end
% 
% %%
% %%2nd. initialize components
% thr=-0.5;
% map=ezConnectedComponent(neighbor, level<=thr & mask);
% 
% %%3rd. iteratively searching for components
% prevThr=thr;
% for thr=-0.4:0.1:1.7
%     disp(thr);
%     region=level>prevThr & level<=thr & mask;
%     
%     %iteratively expand
%     seed=find(map>0);
%     conflict=cell(max(map(:)));
%     while ~isempty(seed)
%         mapclaim=[];
%         for vid=seed'
%             tmp=find(region(neighbor{vid}));
%             if ~isempty(tmp);
%                 mapclaim=[mapclaim;[neighbor{vid}(tmp),ones(length(tmp),1)*map(vid)]];
%             end
%         end
%         nextseed=[];
%         while ~isempty(mapclaim)
%             vid=mapclaim(1,1);
%             region(vid)=0;
%             rid=unique(mapclaim(mapclaim(:,1)==vid,2));
%             if length(rid)<=1 %none confliction
%                 map(vid)=rid;
%                 nextseed=[nextseed; vid];
%             else %confliction, 
%                 %chose the most similar one
%                 %can just use the first one to speed up
%                 mindis=1e16;
%                 minrid=1;
%                 for tmprid=rid'
%                     tmpdis=(level(vid)-mean(level(map==tmprid)));
%                     if tmpdis<mindis
%                         mindis=tmpdis;
%                         minrid=tmprid;
%                     end 
%                 end
%                 map(vid)=minrid;
%             end
%             mapclaim(mapclaim(:,1)==vid,:)=[];
%         end
%         seed=nextseed;
%     end
%     disp(length(unique(map)));
%     
%     %check possible merge
%     map=ezComponentMerge(neighbor, map, level, 0.3);  
%     disp(length(unique(map)));  
%     
%     %cnnected components for the rest regions
%     if sum(region)>0
%         remain=ezConnectedComponent(neighbor, region);
%         map(region)=remain(region)+max(map);
%     end
%     disp(length(unique(map)));  
% %     vtkWritePoints(['result_component_' num2str(thr) '.vtk'],surf.Vtx(:,map>0)',map(map>0));
%     
%     border=ezComponentBorder(neighbor, map);
% %     vtkWritePoints(['result_border_' num2str(thr) '.vtk'],surf.Vtx(:,border)');
%     prevThr=thr;
% end
% vtkWritePoints(['result_component_' num2str(thr) '.vtk'],surf.Vtx(:,map>0)',map(map>0));
% vtkWritePoints(['result_border_' num2str(thr) '.vtk'],surf.Vtx(:,border)');

% %%
% %point skeleton
% foreground=zeros(length(level),1);
% foreground(border)=1;
% foreground(level>0.7)=1;
% skel=zeros(length(level),1);
% while sum(foreground)>0
%     fgero=ezForegroundErosion(neighbor, foreground);
%     fgopen=ezForegroundDialation(neighbor, fgero);
%     skel((foreground-fgopen)>0)=1;
%     foreground=fgero;
% end

% %%
% %edge skeleton
% foreground=zeros(length(level),1);
% foreground(border)=1;
% foreground(level>0.7)=1;
% shifting=1000000;
% elist=zeros(size(face(:))); eid=1;
% for i=1:size(face,2)
%     elist(eid)=[min(face(1,i),face(2,i))*shifting+max(face(1,i),face(2,i))];
%     eid=eid+1;
%     elist(eid)=[min(face(3,i),face(2,i))*shifting+max(face(3,i),face(2,i))];
%     eid=eid+1;
%     elist(eid)=[min(face(1,i),face(3,i))*shifting+max(face(1,i),face(3,i))];
%     eid=eid+1;
% end
% elist=unique(elist);
% elist(elist==0)=[];
% disp(length(elist));
% eneighbor=cell(length(elist),1);
% efore=zeros(length(elist),1);
% for i=1:size(face,2)
%     eid1=find(elist==(min(face(1,i),face(2,i))*shifting+max(face(1,i),face(2,i))),1);
%     eid2=find(elist==(min(face(3,i),face(2,i))*shifting+max(face(3,i),face(2,i))),1);
%     eid3=find(elist==(min(face(1,i),face(3,i))*shifting+max(face(1,i),face(3,i))),1);
%     eneighbor{eid1}=[eneighbor{eid1} eid2 eid3];
%     eneighbor{eid2}=[eneighbor{eid2} eid1 eid3];
%     eneighbor{eid3}=[eneighbor{eid3} eid2 eid1];
%     if(foreground(face(1,i))>0 && foreground(face(2,i))>0) efore(eid1)=1; end
%     if(foreground(face(3,i))>0 && foreground(face(2,i))>0) efore(eid2)=1; end
%     if(foreground(face(1,i))>0 && foreground(face(3,i))>0) efore(eid3)=1; end
% end
% 
% foreground=efore;
% skel=zeros(length(elist),1);
% while sum(foreground)>0
%     fgero=ezForegroundErosion(eneighbor, foreground);
%     fgopen=ezForegroundDialation(eneighbor, fgero);
%     skel((foreground-fgopen)>0)=1;
%     foreground=fgero;
% end
% 
% point=zeros(length(level),1);
% for idx=find(skel>0)'
%     a=floor(elist(idx)/shifting);
%     b=mod(elist(idx),shifting);
%     point(a)=1;
%     point(b)=1;
% end
% %vtkWritePoints(['result_skel.vtk'],surf.Vtx(:,point>0)');
% fp=fopen('result_skel_line.vtk','w');
% plist=find(point>0);
% pid=zeros(length(level),1);
% pid(plist)=0:length(plist)-1;
% fprintf(fp,'# vtk DataFile Version 3.0\nROI Point\nASCII\nDATASET POLYDATA\n');
% fprintf(fp,'POINTS %d float\n',length(plist));
% fprintf(fp, '%f %f %f\n',surf.Vtx(:,plist));
% fprintf(fp,'LINES %d %d\n',sum(skel>0),sum(skel>0)*3);
% for idx=find(skel>0)'
%     a=floor(elist(idx)/shifting);
%     b=mod(elist(idx),shifting);
%     fprintf(fp,'2 %d %d\n',pid(a),pid(b));
% end
% fclose(fp);

%%
%surface skeleton
% foreground=zeros(length(level),1);
% foreground(border)=1;
% foreground(level>0.7)=1;
% vtx_face_map=cell(length(level),1);
% for i=1:size(face,2)
%     vtx_face_map{face(1,i)}=[vtx_face_map{face(1,i)} i];
%     vtx_face_map{face(2,i)}=[vtx_face_map{face(2,i)} i];
%     vtx_face_map{face(3,i)}=[vtx_face_map{face(3,i)} i];
% end
% disp('test');
% %surface neighbor 
% fneighbor_p=cell(size(face,2),1);
% fneighbor_l=cell(size(face,2),1);
% for i=1:length(vtx_face_map)
%     for j=1:length(vtx_face_map{i})
%         f1=vtx_face_map{i}(j);
%         for k=j+1:length(vtx_face_map{i})
%             f2=vtx_face_map{i}(k);
%              if(length(setdiff(face(:,f1),face(:,f2)))>1) %%(only when two triangle share edge)
%                 fneighbor_l{f1}=[fneighbor_l{f1} f2];
%                 fneighbor_l{f2}=[fneighbor_l{f2} f1];
%              end
%             fneighbor_p{f1}=[fneighbor_p{f1} f2]; %%when two triangle share point
%             fneighbor_p{f2}=[fneighbor_p{f2} f1];
%         end
%     end
% end
% ffore=zeros(size(face,2),1);
% for i=1:size(face,2)
%     if(sum(foreground(face(:,i)))>2)
%         ffore(i)=1;
%     end
% end

fforeground=ffore;
skel=zeros(size(face,2),1);
tmpid=1;
while sum(fforeground)>0
    point=zeros(length(level),1);
    for idx=find(fforeground>0)'
        point(face(:,idx))=1;
    end
    vtkWritePoints(['result_iter' num2str(tmpid) '.vtk'],surf.Vtx(:,point>0)');
    tmpid=tmpid+1;
    
    fgero=ezForegroundErosion(fneighbor_p, fforeground);
    fgopen=ezForegroundDialation(fneighbor_p, fgero);
    skel_tmp=skel;
    skel((fforeground-fgopen)>0)=1;
    if(sum(skel_tmp==skel)==length(skel))
        break;
    end
    fforeground=fgero+ezForegroundDialation(fneighbor_p, skel);
end

point=zeros(length(level),1);
for idx=find(skel>0)'
    point(face(:,idx))=1;
end
vtkWritePoints(['result_skel.vtk'],surf.Vtx(:,point>0)');