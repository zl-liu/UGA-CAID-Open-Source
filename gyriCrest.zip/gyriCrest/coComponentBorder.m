%cojoc(at)hotmail.com
%connected region
%region: 1 foreground, 0 background
%neighbor{i}: the neighbors of vtx i
function [border]=coComponentBorder(neighbor, label)
    components=unique(label);
    components=components(components>0);
    border=[];
    for cid=components'
        regions=[];
        for vid=find(label==cid)'
            regions=[regions; neighbor{vid}];
        end
        regions=unique(regions);
        tmp=unique(label(regions));
        tmp(tmp<=0)=[];
        tmp(tmp==cid)=[];
        for i=1:length(tmp)
            crid=tmp(i);
            border=[border;intersect(find(label==crid),regions)];
        end
    end
end