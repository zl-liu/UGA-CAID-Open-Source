%cojoc(at)hotmail.com
%2015/2/16
%addpath ../myVtk
folder='/home/caidGroup/Researcher/uga_hanbo/datasets/tmp/test1/0/surf/';
addpath /home/exe/freesurfer/matlab
%parameters
lvl_fg_thr=0.7; %foreground sulc level threshold, watershed stops here, higher than this are all gyri
lvl_bg_thr=-1; %backround sulc level threshold, watershed starts here, lower than this are all sulci
lvldiff_merge_thr=0.3; %if the depth of pool is smaller than this, it will be merged 
conn_disThr=40; %when distance between two tree neighbor is larger than this, connect them
trim_iter=30;
trim_lenThr=10;

%load data
[vtx,face]=read_surf([folder '/lh.white']);
face=face'+1;
vtx=vtx';
thickness=read_curv([folder '/lh.thickness']);
level=read_curv([folder '/lh.sulc']);
level=level*-1;

disp('Initializing');
%
%1st. construct neighborhood
neighbor=cell(size(vtx,2),1);
for i=1:size(face,2)
    neighbor{face(1,i)}=[neighbor{face(1,i)};face(2:3,i)];
    neighbor{face(2,i)}=[neighbor{face(2,i)};face([1 3],i)];
    neighbor{face(3,i)}=[neighbor{face(3,i)};face(1:2,i)];
end
for i=1:length(neighbor)
    neighbor{i}=unique(neighbor{i});
end

%%
%%init mask to remove cc
tmp=coConnectedComponent(neighbor, thickness==0);
max_comp=1;
max_size=0;
for i=1:max(tmp)
    if(sum(tmp==i)>max_size)
        max_size=sum(tmp==i);
        max_comp=i;
    end
end
roi=tmp~=max_comp;

disp('watershed grow');
%%
%%2nd. initialize components
map=coConnectedComponent(neighbor, level<=lvl_bg_thr & roi);

%%3rd. iteratively searching for components
prevThr=lvl_bg_thr;
for thr=lvl_bg_thr:0.1:lvl_fg_thr+0.1
%     disp(thr);
    region=level>prevThr & level<=thr & roi;
    
    %iteratively expand
    seed=find(map>0);
    conflict=cell(max(map(:)));
    while ~isempty(seed)
        mapclaim=[];
        for vid=seed'
            tmp=find(region(neighbor{vid}));
            if ~isempty(tmp);
                mapclaim=[mapclaim;[neighbor{vid}(tmp),ones(length(tmp),1)*map(vid)]];
            end
        end
        nextseed=[];
        while ~isempty(mapclaim)
            vid=mapclaim(1,1);
            region(vid)=0;
            rid=unique(mapclaim(mapclaim(:,1)==vid,2));
            if length(rid)<=1 %none confliction
                map(vid)=rid;
                nextseed=[nextseed; vid];
            else %confliction, 
                %chose the most similar one
                %can just use the first one to speed up
                mindis=1e16;
                minrid=1;
                for tmprid=rid'
                    tmpdis=(level(vid)-mean(level(map==tmprid)));
                    if tmpdis<mindis
                        mindis=tmpdis;
                        minrid=tmprid;
                    end 
                end
                map(vid)=minrid;
            end
            mapclaim(mapclaim(:,1)==vid,:)=[];
        end
        seed=nextseed;
    end
%     disp(length(unique(map)));
    
    %check possible merge
    if thr==1
    end
    map=coComponentMerge(neighbor, map, level, lvldiff_merge_thr);  
%     disp(length(unique(map)));  
    
    %cnnected components for the rest regions
    if sum(region)>0
        remain=coConnectedComponent(neighbor, region);
        map(region)=remain(region)+max(map);
    end
%     disp(length(unique(map)));  
%     vtkWritePoints(['result_component_' num2str((thr-lvl_bg_thr)*10) '.vtk'],vtx(:,map>0)',map(map>0));
    
    border=coComponentBorder(neighbor, map);
%     vtkWritePoints(['result_border_' num2str((thr-lvl_bg_thr)*10) '.vtk'],vtx(:,border)');
    prevThr=thr;
end
vtkWritePoints(['result_component_' num2str(thr) '.vtk'],vtx(:,map>0)',map(map>0));
vtkWritePoints(['result_border_' num2str(thr) '.vtk'],vtx(:,border)');

disp('skeleton: distance transform');
%%
%point skeleton
foreground=zeros(length(level),1)>0;
foreground(border)=1;
foreground(level>lvl_fg_thr & roi)=1;
% vtkWritePoints(['result_foreground_' num2str(thr) '.vtk'],vtx(:,foreground>0)');
dismap=zeros(length(level),1);
mask=uint8(foreground);
dis=1;
while max(mask)==1
    for i=find(mask)'
        if(sum(mask(neighbor{i}))<length(neighbor{i}))
            dismap(i)=dis;
        end
    end
    mask(dismap>0)=0;
    dis=dis+1;
end
for mdis=1:max(dismap)
    for idx=find(dismap==mdis)'
        dismap(idx)=mdis-1+sum(dismap(neighbor{idx})>mdis-1)/length(neighbor{idx});
    end
end
vtkWritePoints(['result_foreground_' num2str(thr) '.vtk'],vtx(:,foreground)',dismap(foreground));


disp('skeleton: marching tree');

parent=zeros(length(level),1);
grandparent=zeros(length(level),1);
extraConn=[];
comp=zeros(length(level),1);
compid=1;
% energy=zeros(length(level),1);
mask(:)=0;
step=0.5;
for curdis=[max(dismap)-step:-step:step, 0]
    %1st, marching from existing
    seed=find((parent~=0) & (mask==0));
    mask1=mask;
    while ~isempty(seed)
        newseed=[];
        for sid=1:length(seed)
            i=seed(sid);
            cid=neighbor{i};
            if(sum((parent(cid)==0) & (dismap(cid)>0))==0)
                mask(i)=1; %there is no available neibor from this point anymore
                mask1(i)=1;
                continue;
            end
            %search for next martching regions
            idx=find((parent(cid)==0) & (dismap(cid)>curdis));
            if(~isempty(idx))
                newseed=[newseed;cid(idx)];
            else
                mask1(i)=1; %in curdis, no more region can be grow from this seed
            end
        end
        seed=unique(newseed);
        for sid=1:length(seed)
            i=seed(sid);
            ptmp=neighbor{i};
            ptmp=ptmp(parent(ptmp)~=0); %find the already connected point to connect
            ctmp=unique(comp(ptmp)); %component id
            if(length(ctmp)==1) %only one component?
                [ignore idx]=max(dismap(ptmp));
                parent(i)=ptmp(idx);
                grandparent(i)=grandparent(ptmp(idx));
                comp(i)=ctmp;
            else %two or more components get joint?
                parent(i)=-2;
                grandparent(i)=i;
                for cpi=ctmp' %find the connection to each component
                    qtmp=ptmp(comp(ptmp)==cpi);
                    [ignore idx]=max(dismap(qtmp));
                    extraConn=[extraConn;i,qtmp(idx)];
                end
                for j=2:length(ctmp) %adjust component ID to the first one
                    cpi=ctmp(j);
                    comp(comp==cpi)=ctmp(1);
                end
                comp(i)=ctmp(1);
            end
        end
        seed=find((parent~=0) & (mask1==0)); %find the regions that can keep grow from
    end
    
    %2nd, connect rest
    seed=find((dismap>curdis) & (parent==0));
    while ~isempty(seed)
        [ignore idx]=max(dismap(seed));
        seed=seed(idx);
        parent(seed)=-1;
        grandparent(seed)=seed;
        comp(seed)=compid;
        compid=compid+1;
        
        %grow from this seed
        mask1=mask;
        while ~isempty(seed)
            newseed=[];
            for sid=1:length(seed)
                i=seed(sid);
                cid=neighbor{i};
                if(sum((parent(cid)==0) & (dismap(cid)>0))==0)
                    mask(i)=1; %there is no available neibor from this point anymore
                    mask1(i)=1;
                    continue;
                end
                %search for next martching regions
                idx=find((parent(cid)==0) & (dismap(cid)>curdis));
                if(~isempty(idx))
                    newseed=[newseed;cid(idx)];
                else
                    mask1(i)=1; %in curdis, no more region can be grow from this seed
                end
            end
            seed=unique(newseed);
            for sid=1:length(seed)
                i=seed(sid);
                ptmp=neighbor{i};
                ptmp=ptmp(parent(ptmp)~=0); %find the already connected point to connect
                ctmp=unique(comp(ptmp)); %component id
                if(length(ctmp)==1) %only one component?
                    [ignore idx]=max(dismap(ptmp));
                    parent(i)=ptmp(idx);
                    grandparent(i)=grandparent(ptmp(idx));
                    comp(i)=ctmp;
                else %two or more components get joint? actually this should not happen here
                    parent(i)=-2;
                    grandparent(i)=i;
                    for cpi=ctmp' %find the connection to each component
                        qtmp=ptmp(comp(ptmp)==cpi);
                        [ignore idx]=max(dismap(qtmp));
                        extraConn=[extraConn;i,qtmp(idx)];
                    end
                    for j=2:length(ctmp) %adjust component ID to the first one
                        cpi=ctmp(i);
                        comp(comp==cpi)=ctmp(1);
                    end
                    comp(i)=ctmp(1);
                end
            end
            seed=find((parent~=0) & (mask1==0)); %find the regions that can keep grow from
        end
        
        seed=find((dismap>curdis) & (parent==0));
    end
end

clear G;
G=sparse(length(parent),length(parent)); %graph connection
N=sparse(length(parent),length(parent)); %neighborhood connection
for i=1:length(parent)
    if(parent(i)~=0)
        tmp=neighbor{i};
        idx=(parent(neighbor{i})~=0);
        N(tmp(idx),i)=1;
    end
    if(parent(i)>0)
        G(i,parent(i))=1;
        G(parent(i),i)=1;
    end
end
for i=1:size(extraConn,1)
    G(extraConn(i,1),extraConn(i,2))=1;
    G(extraConn(i,2),extraConn(i,1))=1;
end

%for test
Gout=G; %G;
tmp=find(triu(Gout)>0);
[S,T]=ind2sub([length(neighbor),length(neighbor)],tmp);
fp=fopen('result_tree_before_conn.vtk','w');
fprintf(fp,'# vtk DataFile Version 3.0\nROI Point\nASCII\nDATASET POLYDATA\n');
fprintf(fp,'POINTS %d float\n',length(level));
fprintf(fp,'%f %f %f\n',vtx);
fprintf(fp,'LINES %d %d\n',length(S),length(S)*3);
for i=1:length(S)
    fprintf(fp,'2 %d %d\n',S(i)-1,T(i)-1);
end
fclose(fp);

disp('skeleton: connect tree');

%find the points that are neighbors, but not connected, and not from the
%same tree
tmp=find(triu(G+N)==1);
[Stmp,Ttmp]=ind2sub([length(neighbor),length(neighbor)],tmp);
S=[]; T=[];
for i=1:length(Stmp)
    if(grandparent(Stmp(i))~=grandparent(Ttmp(i)))
        S=[S;Stmp(i)];
        T=[T;Ttmp(i)];
    end
end

testCount=0;
testG=sparse(length(parent),length(parent)); %graph connection
while ~isempty(S)
    %remove the ones that are close to each other
    distmax=0;fgi=1;fgj=1;
    for i=length(S):-1:1
        dist = graphshortestpath(G, S(i), T(i));
        if(dist<conn_disThr)
            S(i)=[];
            T(i)=[];
        elseif(dist>distmax)
            distmax=dist;
            fgi=S(i);
            fgj=T(i);
        end
    end
    %connect the pair with largest distance
    if(distmax>0)
        G(fgi,fgj)=1;
        G(fgj,fgi)=1;
        testG(fgi,fgj)=1;
        testG(fgj,fgi)=1;
        testCount=testCount+1;
%         disp([testCount length(S) length(T)]);
    end
end

%for test
Gout=G; %G;
tmp=find(triu(Gout)>0);
[S,T]=ind2sub([length(neighbor),length(neighbor)],tmp);
fp=fopen('result_tree_before_trim.vtk','w');
fprintf(fp,'# vtk DataFile Version 3.0\nROI Point\nASCII\nDATASET POLYDATA\n');
fprintf(fp,'POINTS %d float\n',length(level));
fprintf(fp,'%f %f %f\n',vtx);
fprintf(fp,'LINES %d %d\n',length(S),length(S)*3);
for i=1:length(S)
    fprintf(fp,'2 %d %d\n',S(i)-1,T(i)-1);
end
fclose(fp);

disp('skeleton: trim tree');

%trim the branches
trimG=G;
for j=1:trim_iter
    pdel=[];
    list=find(sum(trimG)>0);
    [ignore p]=sort(level(list));
    list=list(p); %first trim the one with smaller gyrification index
    for i=list
        if(sum(trimG(i,:))==1) %dead end
            tmpdel=[];
            idx=i;
            tmpdel=[tmpdel,idx];
            pre=idx;
            idx=find(trimG(idx,:)==1);
            conn=find(trimG(idx,:)==1);
            while length(conn)==2 %path from dead end to the fork
                if(conn(1)==pre)
                    tmpdel=[tmpdel,idx];
                    pre=idx;
                    idx=conn(2);
                    conn=find(trimG(idx,:)==1);
                else
                    tmpdel=[tmpdel,idx];
                    pre=idx;
                    idx=conn(1);
                    conn=find(trimG(idx,:)==1);
                end
            end
            if(length(tmpdel)<trim_lenThr)
                pdel=[pdel,tmpdel];
            end
        end
    end

%     disp([j,full(sum(sum(trimG))),length(pdel)]);
    if(isempty(pdel))
        break;
    end
    trimG(pdel,:)=0;
    trimG(:,pdel)=0;    
end

disp('output');

Gout=trimG; %G;
tmp=find(triu(Gout)>0);
[S,T]=ind2sub([length(neighbor),length(neighbor)],tmp);
fp=fopen('result_tree_skel.vtk','w');
fprintf(fp,'# vtk DataFile Version 3.0\nROI Point\nASCII\nDATASET POLYDATA\n');
fprintf(fp,'POINTS %d float\n',length(level));
fprintf(fp,'%f %f %f\n',vtx);
fprintf(fp,'LINES %d %d\n',length(S),length(S)*3);
for i=1:length(S)
    fprintf(fp,'2 %d %d\n',S(i)-1,T(i)-1);
end
fclose(fp);
